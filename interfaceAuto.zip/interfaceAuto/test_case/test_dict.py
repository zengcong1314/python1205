#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/1 下午5:06
# @Author  : yuan.li
# 字典管理
import pytest
import random
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-permission"
# 参数
dictId = ""
dictDataId = ""
dictCodeRandom = "dict00" + str(random.randint(10000,999999999))    # 字典标识
listParam = {"limit": 20, "pageNo": 1}
addDictJson = {"dictCode": dictCodeRandom, "id": 0, "dictName": "test01", "remark": "test01"}


@pytest.mark.usefixtures("get_token")
class TestDictClass():

    # 新增字典
    def test_add_dict(self):
        url = baseUrl + "/dict/type"
        res = send.request_api("POST", url, '', addDictJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取字典列表
    def test_get_dict_list(self):
        url = baseUrl + "/dict/type/list"
        res = send.request_api("GET", url, '', listParam)
        global dictId
        dictId = res.json()['data']['records'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 新增字典数据
    def test_add_dict_data(self):
        for i in range(2):
            url = baseUrl + "/dict/data"
            res = send.request_api("POST", url, '', getAddDictDataJson())
            assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 字典数据列表
    def test_get_dict_data_list(self):
        url = baseUrl + "/dict/data/" + str(dictId) + "/list"
        res = send.request_api("GET", url, '')
        global dictDataId
        dictDataId = res.json()['data'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑字典数据
    def test_edit_dict_data(self):
        url = baseUrl + "/dict/data"
        res = send.request_api("PUT", url, '', getEditDictDataJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除字典数据
    def test_delete_dict_data(self):
        url = baseUrl + "/dict/data/" + str(dictDataId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑字典
    def test_edit_dict(self):
        url = baseUrl + "/dict/type"
        res = send.request_api("PUT", url, '', getEditDictJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除字典
    def test_delete_dict(self):
        url = baseUrl + "/dict/type/" + str(dictId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# 参数 - 编辑字典
def getEditDictJson():
    jsonData = {"id": dictId, "dictCode": dictCodeRandom, "dictName": "test01", "remark": "test01"}
    return jsonData
# 参数 - 新增字典数据
def getAddDictDataJson():
    jsonData = {"id":0, "dictId":dictId, "dataLabel":"test01" + str(random.randint(10000,999999999)), "dataValue":"test01" + str(random.randint(10000,999999999)),"remark":"","isSet":"true","seq":"1"}
    return jsonData
# 参数 - 编辑字典数据
def getEditDictDataJson():
    jsonData = {"dictId": dictId, "id": dictDataId, "dataLabel": "test0001", "dataValue": "test0001", "isSet": "false", "remark": "", "seq": "2"}
    return jsonData


if __name__ == "__main__":
    testDict = TestDictClass()
