#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/3 下午4:53
# @Author  : yuan.li
# 移动平台 - 设备管理
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-notify"
# 参数化
getDeviceListParams = [
    pytest.param({"pageNo": 1, "limit": 10, "userName": "", "deviceName": ""}, id="limit=10"),
    pytest.param({"pageNo": 1, "limit": 20, "userName": "", "deviceName": ""}, id="limit=20"),
    pytest.param({"pageNo": 1, "limit": 30, "userName": "", "deviceName": ""}, id="limit=30"),
    pytest.param({"pageNo": 1, "limit": 40, "userName": "", "deviceName": ""}, id="limit=40"),
    pytest.param({"pageNo": 2, "limit": 20, "userName": "", "deviceName": ""}, id="pageNo=2"),
    pytest.param({"pageNo": 1, "limit": 20, "userName": "liyuan", "deviceName": ""}, id="username=liyuan"),
    pytest.param({"pageNo": 1, "limit": 20, "userName": "", "deviceName": "OPPO"}, id="deviceName=OPPO")
]


@pytest.mark.usefixtures("get_token")
class TestMobileDeviceManageClass():
    # 获取移动设备列表
    @pytest.mark.parametrize("params", getDeviceListParams)
    def test_get_device_list(self, params):
        url = baseUrl + "/deviceInfo/list"
        res = send.request_api("GET", url, '', params)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


if __name__ == "__main__":
    testDevice = TestMobileDeviceManageClass()
