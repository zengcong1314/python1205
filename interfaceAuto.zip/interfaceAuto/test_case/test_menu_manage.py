#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午5:37
# @Author  : yuan.li
# 角色管理
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-permission"

# 参数
sysId = ""


@pytest.mark.usefixtures("get_token")
class TestMenuManageClass():
    # 获取系统列表
    def test_get_sys_list(self):
        url = baseUrl + "/sys/admin"
        res = send.request_api("GET", url, '')
        global sysId
        sysId = res.json()['data'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取菜单列表
    def test_get_menu_list(self):
        url = baseUrl + "/menu/list"
        res = send.request_api("GET", url, '', getMenuListParams())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

# 参数 - 获取菜单列表
def getMenuListParams():
    params = {"name": "", "sysId": sysId}
    return params


if __name__ == "__main__":
    testMenu = TestMenuManageClass()
