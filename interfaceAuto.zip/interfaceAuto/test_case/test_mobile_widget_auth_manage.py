#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/8 下午8:36
# @Author  : yuan.li
# 轻应用权限管理
import random
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-mobile"

# 参数
widgetCategoryParams = {'limit': 20, 'pageNo': 1}
widgetParams = {'categoryId': 0, 'appId': ''}


@pytest.mark.usefixtures("get_token")
class TestWidgetAuthManageClass():
    # 角色列表
    def test_role_list(self):
        url = baseUrl + "/widget/role/grant/role"
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 轻应用分类列表
    def test_widget_category_list(self):
        url = baseUrl + "/widgetSettingCategory/list"
        res = send.request_api("GET", url, '', widgetCategoryParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 轻应用列表
    def test_widget_list(self):
        url = baseUrl + "/widget/main/list/get"
        res = send.request_api("GET", url, '', widgetParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


if __name__ == "__main__":
    testWidgetAuthManage = TestWidgetAuthManageClass()