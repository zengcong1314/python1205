#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午1:45
# @Author  : yuan.li
# 系统管理
import pytest
import random
from common.config import Config
from common.sendRequest import SendRequest

# 配置项
conf = Config()
send = SendRequest()
baseUrl = "/api/poros-permission"
username = conf.get_value("user.conf", "user", "username")

# 参数
sysCodeRandom = "sys00" + str(random.randint(10000,999999999))
sysId = ""
addSysJson = {"sysName": "test01", "sysCode": sysCodeRandom, "description": "test01", "uids": [username]}
getSysParams = {"pageNo": 1, "limit": 20, "sysName": ""}


@pytest.mark.usefixtures("get_token")
class TestSysClass():
    # 新增系统
    def test_add_sys(self):
        url = baseUrl + "/sys"
        res = send.request_api("POST", url, '', addSysJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取系统列表
    def test_get_sys_list(self):
        url = baseUrl + "/sys/list"
        res = send.request_api("GET", url, '', getSysParams)
        global sysId
        sysId = res.json()['data']['records'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑系统
    def test_edit_sys(self):
        url = baseUrl + "/sys"
        res = send.request_api("PUT", url, '', getEditSysJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除系统
    def test_delete_sys(self):
        url = baseUrl + "/sys/" + str(sysId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# 参数 -编辑系统
def getEditSysJson():
    jsonData = {"id": sysId, "sysName": "test01", "sysCode": sysCodeRandom, "description": "test01", "uids": [username], "sysIndex": None, "icon": None}
    return jsonData


if __name__ == "__main__":
    testSys = TestSysClass()
