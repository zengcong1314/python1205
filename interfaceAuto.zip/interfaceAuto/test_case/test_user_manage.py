#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午2:10
# @Author  : yuan.li
# 用户管理
import pytest
import random
import string
from common.config import Config
from common.sendRequest import SendRequest

# 配置项
conf = Config()
send = SendRequest()
baseUrl = "/api/poros-permission"
username = conf.get_value("user.conf", "user", "username")
sysCodeRandom = "sys00" + str(random.randint(10000,999999999))

# 参数
uid = ""
phoneRandom = "135" + str(random.randint(10000000, 99999999))
emailRandom = ''.join(random.sample(string.ascii_letters + string.digits, 5)) + "@qq.com"   # 从a-zA-Z0-9生成指定数量的随机字符
addUserJson = {"uid": phoneRandom, "mobile": phoneRandom, "email": emailRandom, "name": "test10086", "departmentNumber": ""}
getUserParams = {"pageNo": 1, "limit": 20, "keyword": "", "orgCode": ""}
getRegParams = {"pageNo": 1, "limit": 20, "status": "2"}
getPassedParams = {"pageNo": 1, "limit": 20, "status": "2"}


@pytest.mark.usefixtures("get_token")
class TestUserClass():
    # 新增用户
    def test_add_user(self):
        url = baseUrl + "/secStaff"
        res = send.request_api("POST", url, '', addUserJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取用户列表
    def test_get_user_list(self):
        url = baseUrl + "/secStaff/list"
        res = send.request_api("GET", url, '', getUserParams)
        global uid
        uid = res.json()['data']['records'][0]['uid']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑用户
    def test_edit_user(self):
        url = baseUrl + "/secStaff"
        res = send.request_api("PUT", url, '', getEditUserJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 禁用用户
    def test_disable_user(self):
        url = baseUrl + "/secStaff/status"
        res = send.request_api("PUT", url, '', getDisableUserJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 启用用户
    def test_start_user(self):
        url = baseUrl + "/secStaff/status"
        res = send.request_api("PUT", url, '', getStartUserJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取待审核列表
    def test_get_reg_list(self):
        url = baseUrl + "/secUserReg/list"
        res = send.request_api("GET", url, '', getRegParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取审核通过列表
    def test_get_passed_list(self):
        url = baseUrl + "/secUserReg/list"
        res = send.request_api("GET", url, '', getPassedParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除用户
    def test_delete_user(self):
        url = baseUrl + "/secStaff/" + uid
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# 参数 - 编辑用户
def getEditUserJson():
    jsonData = {"uid": uid, "mobile": phoneRandom, "name": "test01", "email": emailRandom, "departmentNumber": ""}
    return jsonData
# 参数 - 禁用用户
def getDisableUserJson():
    jsonData = {"uid": uid, "status": "0"}
    return jsonData
# 参数 - 启用用户
def getStartUserJson():
    jsonData = {"uid": uid, "status": "1"}
    return jsonData


if __name__ == "__main__":
    testUser = TestUserClass()

