#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午2:46
# @Author  : yuan.li
# 行政组织
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-permission"

# 参数
getAdminOrgParams = [pytest.param({"name": "leader", "dataSources": 1}, id="search=leader"),
                     pytest.param({"name": "", "dataSources": 1}, id="search=")]


@pytest.mark.usefixtures("get_token")
class TestAdminOrgClass():
    # 获取行政组织列表
    @pytest.mark.parametrize("params", getAdminOrgParams)
    def test_get_admin_org_list(self, params):
        url = baseUrl + "/sys/list"
        res = send.request_api("GET", url, '', params)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# @pytest.fixture(scope="module")
# def get_header():
#     global token
#     token = conf.get_value("user.conf", "headers", "token")
#     print('conf 文件中读取出来的 token: %s' % token)
#     headers['authorization'] = "bearer " + token
#     print('get_header 中的 header: %s' % headers)


if __name__ == "__main__":
    testAdminOrg = TestAdminOrgClass()
