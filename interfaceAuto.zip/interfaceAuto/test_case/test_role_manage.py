#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午5:15
# @Author  : yuan.li
# 角色管理
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-permission"

# 参数
sysId = ""


@pytest.mark.usefixtures("get_token")
class TestRoleManageClass():
    # 获取系统列表
    def test_get_sys_list(self):
        url = baseUrl + "/sys/admin"
        res = send.request_api("GET", url, '')
        global sysId
        sysId = res.json()['data'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取角色列表
    def test_get_role_list(self):
        if sysId != "":
            url = baseUrl + "/role/list"
            res = send.request_api("GET", url, '', getRoleListParams())
            assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

# 参数 - 获取角色列表
def getRoleListParams():
    params = {"pageNo": 1, "limit": 20, "condition": "", "sysId": sysId}
    return params


if __name__ == "__main__":
    testRoleManage = TestRoleManageClass()
