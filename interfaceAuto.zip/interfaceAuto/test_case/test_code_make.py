#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午8:44
# @Author  : yuan.li
# 代码生成
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-generator"


@pytest.mark.usefixtures("get_token")
class TestCodeMakeClass():
    # 获取代码生成
    def test_get_code_make_list(self):
        url = baseUrl + "/connInfo/list"
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


if __name__ == "__main__":
    testCodeMake = TestCodeMakeClass()
    testCodeMake.test_get_code_make_list()
