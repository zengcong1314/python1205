#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/2 下午4:23
# @Author  : yuan.li
# 消息推送
import pytest
import random
from common.sendRequest import SendRequest
from common.config import Config

# 配置项
conf = Config()
send = SendRequest()
baseUrl = "/api/poros-notify"
# 参数
mail = conf.get_value("user.conf", "user", "mail")
tplId = ""  # 模板ID
tplKey = "" # 模板标识
tplKeyRandom = "mail00" + str(random.randint(10000,999999999))    # 模板标识
mailSetId = 0   # 邮箱配置ID
getMailListParams = {"keyword": "", "pageNo": 1, "limit": 20}
# 短信
smsTplIdRandom = "sms00" + str(random.randint(10000,999999999))
smsId = ""
smsTplId = ""
addSmsTplJson = {"tplId": smsTplIdRandom, "tplName": "test001", "sign": "test001", "tplContent": "test001", "tplDesc": "test001"}
getSmsListParams = {"keyword": "", "limit": 20, "pageNo": 1}


@pytest.mark.usefixtures("get_token")
class TestEmailMsgClass():
    # 新增邮件模板
    def test_add_mail_tpl(self):
        url = baseUrl + "/mail/template"
        res = send.request_api("POST", url, '', getAddMailTplJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取邮件模板列表
    def test_get_mail_list(self):
        url = baseUrl + "/mail/template/list"
        res = send.request_api("GET", url, '', getMailListParams)
        global tplId
        tplId = res.json()['data']['records'][0]['id']
        global tplKey
        tplKey = res.json()['data']['records'][0]['tplKey']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑邮件模板
    def test_edit_mail_tpl(self):
        url = baseUrl + "/mail/template"
        res = send.request_api("PUT", url, '', getEditMailTplJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取邮箱配置
    def test_get_mail_set(self):
        url = baseUrl + "/mail/config/all"
        res = send.request_api("GET", url, '')
        global mailSetId
        mailSetId = res.json()['data'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 发送测试
    def test_send_mail(self):
        if mailSetId > 0:
            url = baseUrl + "/mail/send/sendByRecAddr"
            res = send.request_api("POST", url, '', getSendMailJson())
            assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除邮件模板
    def test_delete_mail_tpl(self):
        url = baseUrl + "/mail/template/" + str(tplId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 新增短信模板
    def test_add_sms_tpl(self):
        url = baseUrl + "/tencent/sms/config"
        res = send.request_api("POST", url, '', addSmsTplJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 短信模板列表
    def test_get_sms_list(self):
        url = baseUrl + "/tencent/sms/config/list"
        res = send.request_api("GET", url, '', getSmsListParams)
        global smsId
        smsId = res.json()['data']['records'][0]['id']
        global smsTplId
        smsTplId = res.json()['data']['records'][0]['tplId']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑短信模板
    def test_edit_mail_tpl(self):
        url = baseUrl + "/tencent/sms/config"
        res = send.request_api("PUT", url, '', getEditSmsTplJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除短信模板
    def test_delete_sms_tpl(self):
        url = baseUrl + "/tencent/sms/config/" + str(smsId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取短信配置
    def test_get_sms_set(self):
        url = baseUrl + "/tencentcloud/config/all"
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取企业微信设置
    def test_get_wechart_set(self):
        url = baseUrl + "/weixinConfig/all"
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# 参数 - 新增邮件模板
def getAddMailTplJson():
    jsonData = {
        "id":0,
        "tplName":"mail001",
        "tplKey": tplKeyRandom,
        "tplParams":[{"param":"param1","remark":"参数1"}],
        "tplContent":"<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"utf-8\"> \n<title>菜鸟教程(runoob.com)</title> \n<meta name=\"description\" content=\"免费在线教程\">\n<meta name=\"keywords\" content=\"HTML,CSS,XML,JavaScript\">\n<meta name=\"author\" content=\"runoob\">\n\t<meta http-equiv=\"refresh\" content=\"5\">\n<meta charset=\"UTF-8\">\n</head>\n<body>\n<h1>{{param1}}\n<p>所有 meta 标签显示在 head 部分...</p>\n</body>\n</html>","remark":"mail001"
    }
    return jsonData
# 参数 - 编辑邮件模板
def getEditMailTplJson():
    jsonData = {
        "id": tplId,
        "tplName": "mail001",
        "tplKey": tplKey,
        "remark": tplKeyRandom,
        "tplParams":[{"param":"param1","remark":"参数1"}],
        "tplContent":"<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"utf-8\"> \n<title>菜鸟教程(runoob.com)</title> \n<meta name=\"description\" content=\"免费在线教程\">\n<meta name=\"keywords\" content=\"HTML,CSS,XML,JavaScript\">\n<meta name=\"author\" content=\"runoob\">\n\t<meta http-equiv=\"refresh\" content=\"5\">\n<meta charset=\"UTF-8\">\n</head>\n<body>\n<h1>{{param1}}\n<p>所有 meta 标签显示在 head 部分...</p>\n</body>\n</html>","remark":"mail001"
    }
    return jsonData
# 参数 - 发送测试
def getSendMailJson():
    jsonData = {"mailTemplateId": tplKey, "receiverAddr": mail, "paramsMap": {"param1": "参数1"}}
    return jsonData
# 参数 - 编辑短信模板
def getEditSmsTplJson():
    jsonData = {"id": smsId, "tplId": smsTplId, "tplName": "test001", "sign": "test001", "tplContent": "test001", "tplDesc": "test001"}
    return jsonData


if __name__ == "__main__":
    testEmailMsg = TestEmailMsgClass()
