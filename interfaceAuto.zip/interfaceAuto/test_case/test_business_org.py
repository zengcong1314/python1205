#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午4:27
# @Author  : yuan.li
# 业务组织
import pytest
import random
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-permission"

# 参数
uid = ""
orgCodeRandom = "org00" + str(random.randint(10000,999999999))
getBusOrgParams = {"name": "", "dataSources": 0}
addBusOrgJson = {"name":"test01", "parentCode":"00000000", "code": orgCodeRandom}
editBusOrgJson = {"name":"test02", "parentCode":"00000000", "code": orgCodeRandom}
getRelatedUserParams = {"orgCode": orgCodeRandom}
getAllUserParams = {"pageNo": 1, "limit": 20, "keyword": "", "orgCode": "", "status": 1}
relatedUserJson = {"orgCode": orgCodeRandom, "uids": uid}
deleteRelatedUserJson = {"orgCode": orgCodeRandom, "uids": ""}


@pytest.mark.usefixtures("get_token")
class TestBusinessOrgClass():
    # 获取业务组织列表
    def test_get_business_org_list(self):
        url = baseUrl + "/secOrg/bizList"
        res = send.request_api("GET", url, '', getBusOrgParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 新增业务组织
    def test_add_business_org(self):
        url = baseUrl + "/secOrg"
        res = send.request_api("POST", url, '', addBusOrgJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑业务组织
    def test_edit_business_org(self):
        url = baseUrl + "/secOrg"
        res = send.request_api("PUT", url, '', editBusOrgJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取已关联用户列表
    def test_get_related_user_list(self):
        url = baseUrl + "/secOrg/getRelatedUser"
        res = send.request_api("GET", url, '', getRelatedUserParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取全部用户列表
    def test_get_all_user_list(self):
        url = baseUrl + "/secStaff/list"
        res = send.request_api("GET", url, '', getAllUserParams)
        global uid
        uid = res.json()['data']['records'][0]['uid']
        relatedUserJson['uids'] = uid
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 关联用户
    def test_related_user(self):
        url = baseUrl + "/secOrg/relatedUser"
        res = send.request_api("POST", url, '', relatedUserJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除全部关联用户
    def test_delete_related_user(self):
        url = baseUrl + "/secOrg/relatedUser"
        res = send.request_api("POST", url, '', deleteRelatedUserJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除业务组织
    def test_delete_business_org(self):
        url = baseUrl + "/secOrg/" + orgCodeRandom
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


if __name__ == "__main__":
    testBusinessOrg = TestBusinessOrgClass()

