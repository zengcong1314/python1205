#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午8:56
# @Author  : yuan.li
# 原生应用管理
import pytest
import random
from common.config import Config
from common.sendRequest import SendRequest

# 配置项
conf = Config()
send = SendRequest()
baseUrl = "/api/poros-mobile"
baseOssUrl = "/api/poros-oss"
data_path = conf.data_path

# 参数
appRandom = str(random.randint(10000,999999999))
imageUrl = ""   # 应用图标
appId = ""  # 应用ID列表
appName = ""    # 应用名称
appIdentifier = ""  # 应用标识
iosIpaUrl = ""  # ios ipa url
iosVersionId = ""   # ios 版本ID
roleId = "" # 角色ID
androidApkUrl = ""  # android apk url
androidVersionId = ""   # android 版本ID


@pytest.mark.usefixtures("get_token")
class TestAppManageClass():
    # 上传应用图片
    def test_upload_app_image(self):
        url = baseOssUrl + "/file/upload?bucketName=poros&expireDate=0"
        files = {'file': open(str(data_path) + "/test_ad_image01.jpg", 'rb')}
        res = send.request_api("UPLOAD", url, '', files)
        global imageUrl
        imageUrl = res.json()['data']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 下载应用图片
    def test_download_app_image(self):
        res = send.request_api("DOWNLOAD", url=imageUrl, headers=None)
        assert res.status_code == 200 and res.content is not None

    # 新增原生应用
    def test_add_app(self):
        url = baseUrl + "/appMain"
        res = send.request_api("POST", url, '', getAddAppJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取原生应用列表
    def test_get_app_list(self):
        url = baseUrl + "/appMain/all"
        res = send.request_api("GET", url, '')
        for i in res.json()['data']:
            print(i)
            if i['remark'] == 'test10086':
                global appId
                appId = i['id']
        print(appId)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 原生应用详情
    def test_get_app_detail(self):
        url = baseUrl + "/appMain/" + str(appId)
        res = send.request_api("GET", url, '')
        global appName
        global appIdentifier
        appName = res.json()['data']['name']
        appIdentifier = res.json()['data']['identifier']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 上传ios安装包
    def test_upload_ios_ipa(self):
        url = baseOssUrl + "/file/upload?bucketName=poros&expireDate=0"
        files = {'file': open(str(data_path) + "/test_upload_ios_ipa01.ipa", 'rb')}
        res = send.request_api("UPLOAD", url, '', files)
        global iosIpaUrl
        iosIpaUrl = res.json()['data']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 新增ios版本
    def test_add_ios_version(self):
        url = baseUrl + "/appVersion"
        res = send.request_api("POST", url, '', getAddIosJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取ios版本列表
    def test_get_ios_version_list(self):
        url = baseUrl + "/appVersion/all"
        res = send.request_api("GET", url, '', getIosVersionParams())
        global iosVersionId
        iosVersionId = res.json()['data'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 克隆ios版本
    def test_clone_ios_version(self):
        url = baseUrl + "/appVersion"
        res = send.request_api("POST", url, '', getCloneIosJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 上架ios版本
    def test_publish_ios_version(self):
        url = baseUrl + "/appVersion/version/publish"
        res = send.request_api("GET", url, '', getStatusIosParams())
        assert res.status_code == 200 and res.json()['msg'] != False and res.json()['code'] == 0

    # 下架ios版本
    def test_down_ios_version(self):
        url = baseUrl + "/appVersion/version/down"
        res = send.request_api("GET", url, '', getStatusIosParams())
        assert res.status_code == 200 and res.json()['msg'] != False and res.json()['code'] == 0

    # 获取ios版本信息
    def test_get_ios_version_info(self):
        url = baseUrl + "/appVersion/" + str(iosVersionId)
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑ios版本信息
    def test_edit_ios_version_info(self):
        url = baseUrl + "/appVersion"
        res = send.request_api("PUT", url, '', getEditIosJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除ios版本
    def test_delete_ios_version(self):
        url = baseUrl + "/appVersion/" + str(iosVersionId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取当前ios版本可添加的角色列表
    def test_ios_role_list_all(self):
        url = baseUrl + "/widget/role/grant/role"
        res = send.request_api("GET", url, '', getRoleListAllParams())
        global roleId
        roleId = res.json()['data'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # if 角色列表不为空
    # 当前ios版本添加定向角色
    def test_ios_add_role(self):
        if roleId is not "":
            url = baseUrl + "/upgrade"
            res = send.request_api("POST", url, '', getIosAddRoleJson())
            assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取当前ios版本添加的定向角色列表
    def test_ios_role_list(self):
        if roleId is not "":
            url = baseUrl + "/upgrade/role/list"
            res = send.request_api("GET", url, '', getIosRoleListParams())
            assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 当前ios版本删除角色
    def test_ios_delete_role(self):
        if roleId is not "":
            url = baseUrl + "/upgrade"
            res = send.request_api("POST", url, '', getIosRoleDeleteJson())
            assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取当前ios版本的轻应用列表
    def test_get_ios_widget_list(self):
        url = baseUrl + "/app/widget/rel/get"
        res = send.request_api("GET", url, '', getIosRoleDeleteJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 上传android安装包
    def test_upload_android_apk(self):
        url = baseOssUrl + "/file/upload?bucketName=poros&expireDate=0"
        files = {'file': open(str(data_path) + "/test_upload_android_apk01.apk", 'rb')}
        res = send.request_api("UPLOAD", url, '', files)
        global androidApkUrl
        androidApkUrl = res.json()['data']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 新增android版本
    def test_add_android(self):
        url = baseUrl + "/appVersion"
        res = send.request_api("POST", url, '', getAddAndroidJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取android版本列表
    def test_get_android_version_list(self):
        url = baseUrl + "/appVersion/all"
        res = send.request_api("GET", url, '', getAndroidVersionParams())
        global androidVersionId
        androidVersionId = res.json()['data'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 克隆android版本
    def test_clone_android_version(self):
        url = baseUrl + "/appVersion"
        res = send.request_api("POST", url, '', getCloneAndroidJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 上架android版本
    def test_publish_android_version(self):
        url = baseUrl + "/appVersion/version/publish"
        res = send.request_api("GET", url, '', getStatusAndroidParams())
        assert res.status_code == 200 and res.json()['msg'] != False and res.json()['code'] == 0

    # 下架android版本
    def test_down_android_version(self):
        url = baseUrl + "/appVersion/version/down"
        res = send.request_api("GET", url, '', getStatusAndroidParams())
        assert res.status_code == 200 and res.json()['msg'] != False and res.json()['code'] == 0

    # 获取android版本信息
    def test_get_android_version_info(self):
        url = baseUrl + "/appVersion/" + str(androidVersionId)
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑android版本信息
    def test_edit_android_version_info(self):
        url = baseUrl + "/appVersion"
        res = send.request_api("PUT", url, '', getEditAndroidJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除android版本信息
    def test_delete_android_version(self):
        url = baseUrl + "/appVersion/" + str(androidVersionId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除原生应用
    def test_delete_app(self):
        url = baseUrl + "/appMain/" + str(appId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# 参数 - 新增原生应用
def getAddAppJson():
    jsonData = {"identifier": "test01.test0" + appRandom, "name":"test0" + appRandom, "remark":"test10086", "icon": imageUrl,"categoryId":0}
    return jsonData
# 参数 - 新增ios版本
def getAddIosJson():
    jsonData = {"appId": appId, "name": appName, "identifier": appIdentifier, "bundleUrl": iosIpaUrl, "version": "v1.0.101", "buildNo": "1", "remark": "test_add_ios_ipa_10086", "forceUpdate": False, "cloneVersion": "", "platform": "ios"}
    return jsonData
# 参数 - 获取ios版本列表
def getIosVersionParams():
    params = {"platform": "ios", "appId": appId}
    return params
# 参数 - 克隆ios版本
def getCloneIosJson():
    jsonData = {"appId": appId, "versionId": iosVersionId, "name": appName, "identifier": appIdentifier, "bundleUrl": iosIpaUrl, "buildNo": "2", "cloneVersion": "v1.0.101", "forceUpdate": False, "platform": "ios", "remark": "test_add_ios_ipa_10086", "version": "v1.0.102"}
    return jsonData
# 参数 - 上架/下架ios版本
def getStatusIosParams():
    params = {"id": iosVersionId}
    return params
# 参数 - 编辑ios版本信息
def getEditIosJson():
    jsonData = {"id": iosVersionId, "name": appName, "identifier": appIdentifier, "bundleUrl": iosIpaUrl, "version": "v1.0.101", "buildNo": "1", "remark": "test_add_ios_ipa_10086", "forceUpdate": "false", "cloneVersion": "", "platform": "ios"}
    return jsonData
# 参数 - 获取当前ios版本可添加的角色列表
def getRoleListAllParams():
    params = {"appVersionId": iosVersionId}
    return params
# 参数 - 当前ios版本添加定向角色
def getIosAddRoleJson():
    jsonData = {"appId":appId, "appVersionId":iosVersionId, "relIds":[roleId], "buildNo":1, "directedType":2, "platform":1}
    return jsonData
# 参数 - 获取当前ios版本添加的定向角色列表
def getIosRoleListParams():
    jsonData = {"appVersionId": iosVersionId}
    return jsonData
# 参数 - 当前ios版本删除角色
def getIosRoleDeleteJson():
    jsonData = {"appId":appId, "appVersionId":iosVersionId, "relIds":[roleId], "buildNo":1, "directedType":2, "platform":1}
    return jsonData
# 参数 - 新增android版本
def getAddAndroidJson():
    jsonData = {"name": appName, "appId": appId, "bundleUrl": androidApkUrl, "identifier": appIdentifier, "version": "v1.0.101", "buildNo": "1", "remark": "test_add_android_apk_10086", "forceUpdate": "false", "cloneVersion": "", "platform": "android"}
    return jsonData
# 参数 - 获取android版本列表
def getAndroidVersionParams():
    params = {"platform": "android", "appId": appId}
    return params
# 参数 - 克隆android版本
def getCloneAndroidJson():
    jsonData = {"appId": appId, "versionId": androidVersionId, "name": appName, "identifier": appIdentifier, "bundleUrl": androidApkUrl, "buildNo": "2", "cloneVersion": "v1.0.101", "forceUpdate": "false", "platform": "android", "remark": "test_add_android_apk_10086", "version": "v1.0.102"}
    return jsonData
# 参数 - 上架/下架android版本
def getStatusAndroidParams():
    params = {"id": androidVersionId}
    return params
# 参数 - 编辑android版本信息
def getEditAndroidJson():
    jsonData = {"bundleUrl": androidApkUrl, "id": androidVersionId, "bundleMd5": None, "forceUpdate": "false", "platform": "android", "plistUrl": None, "remark": "test_add_android_apk_10086", "size": 49457146}
    return jsonData


if __name__ == "__main__":
    testAppManage = TestAppManageClass()

