#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/3 下午4:01
# @Author  : yuan.li
# 统一认证
import pytest
from common.config import Config
from common.sendRequest import SendRequest

# 配置项
conf = Config()
send = SendRequest()
baseUrl = "/api/poros-authcenter"
# 参数
username = conf.get_value("user.conf", "user", "username")
mail = conf.get_value("user.conf", "user", "mail")
mailResetSendcodeJson = {"noToken": "true", "type": 2, "username": str(mail)}
usernameResetSendcodeJson = {"noToken": "true", "type": 1, "username": str(username)}
getMenusParams = {"sysCode": "poros_tech"}


@pytest.mark.usefixtures("get_token")
class TestAuthClass():
    # 用户存在
    def test_user_exist(self):
        url = baseUrl + "/register/isExist?mobile=" + str(username) + "&noToken=true"
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 发送邮件找回密码邮件
    def test_mail_reset_send_code(self):
        url = baseUrl + "/reset/sendCode"
        res = send.request_api("POST", url, '', mailResetSendcodeJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 发送用户名找回密码邮件
    def test_username_reset_send_code(self):
        url = baseUrl + "/reset/sendCode"
        res = send.request_api("POST", url, '', usernameResetSendcodeJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # message
    def test_get_message(self):
        url = baseUrl + "/user/message"
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # menus
    def test_get_menus(self):
        url = "/api/poros-permission/menu/menus"
        res = send.request_api("GET", url, '', getMenusParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


if __name__ == "__main__":
    testAuth = TestAuthClass()
