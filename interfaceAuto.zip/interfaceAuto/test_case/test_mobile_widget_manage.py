#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/8 下午7:55
# @Author  : yuan.li
# 轻应用管理
import random
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-mobile"

# 参数
addCategoryJson = {"name": "newCategory10086"}
getCategoryParams = {"keyword": "", "limit": 1000}
categoryId = "" # 分类ID
widgetId = ""   # 轻应用ID
identifierRandom = str(random.randint(10000,999999999))


@pytest.mark.usefixtures("get_token")
class TestWidgetManageClass():
    # 新增轻应用分类
    def test_add_widget_category(self):
        url = baseUrl + "/widgetSettingCategory"
        res = send.request_api("POST", url, '', addCategoryJson)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 轻应用分类列表
    def test_get_widget_category_list(self):
        url = baseUrl + "/widgetSettingCategory/list"
        res = send.request_api("GET", url, '', getCategoryParams)
        for i in res.json()['data']['records']:
            if i['name'] == 'newCategory10086':
                global categoryId
                categoryId = i['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 当前分类下新增轻应用
    def test_add_widget(self):
        url = baseUrl + "/widget/main"
        res = send.request_api("POST", url, '', getAddWidgetJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取当前分类的轻应用列表
    def test_get_widget_list(self):
        url = baseUrl + "/widget/main/list/get"
        res = send.request_api("GET", url, '', getwidgetListParams())
        global widgetId
        widgetId = res.json()['data']['categoryList'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取轻应用详情
    def test_get_widget_detail(self):
        url = baseUrl + "/widget/main/get/" + str(widgetId)
        res = send.request_api("GET", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑轻应用
    def test_edit_widget(self):
        url = baseUrl + "/widget/main"
        res = send.request_api("PUT", url, '', getEditWidgetJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除轻应用
    def test_delete_widget(self):
        url = baseUrl + "/widget/main/" + str(widgetId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除轻应用分类
    def test_delete_category(self):
        url = baseUrl + "/widgetSettingCategory/" + str(categoryId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# 参数-当前分类下新增轻应用
def getAddWidgetJson():
    jsonData = {'categoryId': categoryId, 'identifier': 'test.test.test' + identifierRandom, 'platform': 3, 'name': 'test01', 'nameEn': '', 'remark': '', 'icon': '', 'msgIcon': '', 'bundleUrl': '', 'buildNo': '1', 'version': 'v1.0.10086', 'size': '', 'releaseNote': '', 'req': 0, 'searchName': '', 'moduleId': '', 'sysCode': '', 'accessUrl': '', 'onlineUrl': '', 'widgetMd5': ''}
    return jsonData

# 参数-获取当前分类的轻应用列表
def getwidgetListParams():
    params = {'categoryId': categoryId}
    return params

# 参数-编辑轻应用
def getEditWidgetJson():
    jsonData = {'id': widgetId, 'platform': 3, 'name': 'test01', 'nameEn': '', 'remark': '', 'icon': '', 'identifier': 'test.test.test' + identifierRandom, 'req': 0, 'searchName': '', 'moduleId': '', 'sysCode': '', 'accessUrl': '', 'onlineUrl': ''}
    return jsonData


if __name__ == "__main__":
    testWidgetManage = TestWidgetManageClass()