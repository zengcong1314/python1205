#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/3 下午4:19
# @Author  : yuan.li
# 日志
import pytest
import datetime
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-log"

# 参数
# 当前时间
currentTime = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# 一小时前
oneHourTime = (datetime.datetime.now()-datetime.timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
# 24小时前
oneDayTime = (datetime.datetime.now()-datetime.timedelta(days=1)).strftime("%Y-%m-%d %H:%M:%S")
# 三天前
threeDayTime = (datetime.datetime.now()-datetime.timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S")
# 一周前
sevenDayTime = (datetime.datetime.now()-datetime.timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S")
# 一个月前
thirtyDayTime = (datetime.datetime.now()-datetime.timedelta(days=30)).strftime("%Y-%m-%d %H:%M:%S")

loginTotal = 0  # 登录 total
auditTotal = 0  # 操作 total
bizTotal = 0    # 业务 total
# 登录日志
loginLogParams = [
    pytest.param({'limit':20, 'pageNo':1, 'log_search': '', 'log_msg_platformType':'', 'log_msg_begin_time': oneHourTime, 'log_msg_end_time': currentTime}, id='login=oneHourTime'),
    pytest.param({'limit':20, 'pageNo':1, 'log_search': '', 'log_msg_platformType':'', 'log_msg_begin_time': oneDayTime, 'log_msg_end_time': currentTime}, id='login=oneDayTime'),
    pytest.param({'limit':20, 'pageNo':1, 'log_search': '', 'log_msg_platformType':'', 'log_msg_begin_time': threeDayTime, 'log_msg_end_time': currentTime}, id='login=threeDayTime'),
    pytest.param({'limit':20, 'pageNo':1, 'log_search': '', 'log_msg_platformType':'', 'log_msg_begin_time': sevenDayTime, 'log_msg_end_time': currentTime}, id='login=sevenDayTime'),
    pytest.param({'limit':20, 'pageNo':1, 'log_search': 'super_admin', 'log_msg_platformType':'MANAGE', 'log_msg_begin_time': thirtyDayTime, 'log_msg_end_time': currentTime}, id='login=search'),
    pytest.param({'limit':20, 'pageNo':1, 'log_search': '', 'log_msg_platformType':'', 'log_msg_begin_time': thirtyDayTime, 'log_msg_end_time': currentTime}, id='login=thirtyDayTime')
]
# 操作日志
auditLogParams = [
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_sername": "", "log_msg_begin_time": oneHourTime, "log_msg_end_time": currentTime}, id="audit=oneHourTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_sername": "", "log_msg_begin_time": oneDayTime, "log_msg_end_time": currentTime}, id="audit=oneDayTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_sername": "", "log_msg_begin_time": threeDayTime, "log_msg_end_time": currentTime}, id="audit=threeDayTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_sername": "", "log_msg_begin_time": sevenDayTime, "log_msg_end_time": currentTime}, id="audit=sevenDayTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "super_admin", "log_msg_sys": "tc-center", "log_msg_sername": "poros-mobile", "log_msg_begin_time": thirtyDayTime, "log_msg_end_time": currentTime}, id="audit=search"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_sername": "", "log_msg_begin_time": thirtyDayTime, "log_msg_end_time": currentTime}, id="audit=thirtyDayTime")
]
# 业务日志
bizLogParams = [
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_level": "", "log_msg_service": "", "log_msg_tid": "","log_msg_begin_time": oneHourTime, "log_msg_end_time": currentTime}, id="biz=oneHourTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_level": "", "log_msg_service": "", "log_msg_tid": "","log_msg_begin_time": oneDayTime, "log_msg_end_time": currentTime}, id="biz=oneDayTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_level": "", "log_msg_service": "", "log_msg_tid": "","log_msg_begin_time": threeDayTime, "log_msg_end_time": currentTime}, id="biz=threeDayTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_level": "", "log_msg_service": "", "log_msg_tid": "","log_msg_begin_time": sevenDayTime, "log_msg_end_time": currentTime}, id="biz=sevenDayTime"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "msg", "log_msg_sys": "tc-center", "log_msg_level": "INFO", "log_msg_service": "bpm-engine-svc", "log_msg_tid": "Ignored Trace","log_msg_begin_time": thirtyDayTime, "log_msg_end_time": currentTime}, id="biz=search"),
    pytest.param({"pageNo": 1, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_level": "", "log_msg_service": "", "log_msg_tid": "","log_msg_begin_time": thirtyDayTime, "log_msg_end_time": currentTime}, id="biz=thirtyDayTime")
]


@pytest.mark.usefixtures("get_token")
class TestLogClass():
    # 登录日志
    @pytest.mark.parametrize("params", loginLogParams)
    def test_get_login_log(self, params):
        url = baseUrl + "/porosLog/getLoginLogList"
        res = send.request_api("GET", url, '', params)
        global loginTotal
        loginTotal = res.json()['data']['total']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 登录日志最后一页
    def test_get_login_log_lastpage(self):
        url = baseUrl + "/porosLog/getLoginLogList"
        res = send.request_api("GET", url, '', getLoginLastPageParams())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 操作日志
    @pytest.mark.parametrize("params", auditLogParams)
    def test_get_audit_log(self, params):
        url = baseUrl + "/porosLog/getAuditLogList"
        res = send.request_api("GET", url, '', params)
        global auditTotal
        auditTotal = res.json()['data']['total']
        assert res.status_code == 200 and res.json()['code'] == 0

    # 操作日志最后一页
    def test_get_audit_log_lastpage(self):
        url = baseUrl + "/porosLog/getAuditLogList"
        res = send.request_api("GET", url, '', getAuditLastPageParams())
        assert res.status_code == 200 and res.json()['code'] == 0

    # 业务日志
    @pytest.mark.parametrize("params", bizLogParams)
    def test_get_biz_log(self, params):
        url = baseUrl + "/porosLog/getBizLogList"
        res = send.request_api("GET", url, '', params)
        global bizTotal
        bizTotal = res.json()['data']['total']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 业务日志最后一页
    def test_get_biz_log_lastpage(self):
        url = baseUrl + "/porosLog/getBizLogList"
        res = send.request_api("GET", url, '', getBizLastPageParams())
        assert res.status_code == 200 and res.json()['code'] == 0


# 参数 - 登录日志最后一页
def getLoginLastPageParams():
    pageNo = int(loginTotal/20)
    lastPageParams = {'limit':20, 'pageNo':pageNo, 'log_search': '', 'log_msg_platformType':'', 'log_msg_begin_time': thirtyDayTime, 'log_msg_end_time': currentTime}
    return lastPageParams
# 参数 - 操作日志最后一页
def getAuditLastPageParams():
    pageNo = int(auditTotal / 20)
    lastPageParams ={"pageNo": pageNo, "limit": 20, "log_search": "", "log_msg_sys": "", "log_msg_sername": "", "log_msg_begin_time": thirtyDayTime, "log_msg_end_time": currentTime}
    return lastPageParams
# 参数 - 业务日志最后一页
def getBizLastPageParams():
    pageNo = int(bizTotal / 20)
    lastPageParams = {"pageNo": 1, "limit": pageNo, "log_search": "", "log_msg_sys": "", "log_msg_level": "", "log_msg_service": "", "log_msg_tid": "","log_msg_begin_time": thirtyDayTime, "log_msg_end_time": currentTime}
    return lastPageParams


if __name__ == "__main__":
    testLog = TestLogClass()
