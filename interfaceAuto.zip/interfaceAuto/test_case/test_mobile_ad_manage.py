#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/3 下午5:16
# @Author  : yuan.li
# 移动平台 - 公告管理
import pytest
import random
from common.config import Config
from common.sendRequest import SendRequest

# 配置项
conf = Config()
send = SendRequest()
baseUrl = "/api/poros-mobile"
data_path = conf.data_path
# 参数
adRandom = "ad00" + str(random.randint(10000,999999999))
adId = ""   # 公告ID
articleId = ""  # 文章ID
adImageUrl = "" # 文章图片
getAdListParams = {"pageNo": 1, "limit": 20, "title": ""}


@pytest.mark.usefixtures("get_token")
class TestMobileAdManageClass():
    # 上传公告图片
    def test_upload_ad_image(self):
        url = "/api/poros-oss/file/upload?bucketName=poros"
        files = {'file': open(str(data_path) + "/test_ad_image01.jpg", 'rb')}
        res = send.request_api("UPLOAD", url, '', files)
        global adImageUrl
        adImageUrl = res.json()['data']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 创建文章公告
    def test_add_article_ad(self):
        url = baseUrl + "/appAd"
        res = send.request_api("POST", url, '', getAddArticleAdJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取公告列表
    def test_get_ad_list(self):
        url = baseUrl + "/appAd/list"
        res = send.request_api("GET", url, '', getAdListParams)
        global adId
        adId = res.json()['data']['records'][0]['id']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 获取公告详情
    def test_get_ad_detail(self):
        url = baseUrl + "/appAd/id"
        res = send.request_api("GET", url, '', getAdDetailParams())
        global articleId
        articleId = res.json()['data']['articleId']
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 编辑文章公告
    def test_edit_article_ad(self):
        url = baseUrl + "/appAd"
        res = send.request_api("POST", url, '', getEditArticleAdJson())
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0

    # 删除公告
    def test_delete_article_ad(self):
        url = baseUrl + "/appAd/ids?ids=" + str(adId)
        res = send.request_api("DELETE", url, '')
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


# 参数 - 创建文章公告
def getAddArticleAdJson():
    jsonData = {"title": adRandom, "remark": "test01", "adImageUrl": adImageUrl, "type": 1, "articleTitle": "test01","richText":"<p>test01</p>"}
    return jsonData
# 参数 - 获取公告详情
def getAdDetailParams():
    params = {"id": adId}
    return params
# 参数 - 编辑文章公告
def getEditArticleAdJson():
    jsonData = {"id": adId, "articleId": articleId, "title":"test01", "remark":"test01", "adImageUrl":"${adImageUrl}", "type":1, "articleTitle":"test01", "richText":"<p>test01</p>", "status": 0, "location": 1}
    return jsonData


if __name__ == "__main__":
    testMobileAdManage = TestMobileAdManageClass()
