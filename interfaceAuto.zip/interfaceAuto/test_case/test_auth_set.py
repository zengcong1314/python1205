#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/5 下午8:39
# @Author  : yuan.li
# 认证配置
import pytest
from common.sendRequest import SendRequest

# 配置项
send = SendRequest()
baseUrl = "/api/poros-authcenter"

# 参数
getAuthSetParams = {"pageNo": 1, "limit": 20, "clientId": ""}


@pytest.mark.usefixtures("get_token")
class TestAuthSetClass():
    # 获取认证配置列表
    def test_get_auth_set_list(self):
        url = baseUrl + "/clientDetails/list"
        res = send.request_api("GET", url, '', getAuthSetParams)
        assert res.status_code == 200 and res.json()['data'] != False and res.json()['code'] == 0


if __name__ == "__main__":
    testAuthSet = TestAuthSetClass()
