#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/2 下午9:09
# @Author  : yuan.li
# session function
import pytest
import requests
from common.config import Config
from pyDes import *
import base64

conf = Config()
env = conf.get_value("run.conf", "execution", "env")    # 获取当前环境
host = conf.get_value("host.conf", env, "host") # 获取当前 host
username = conf.get_value("user.conf", "user", "username") # 获取当前 username
password = conf.get_value("user.conf", "user", "password") # 获取当前 password
baseUrl = host + "/api/poros-authcenter"
desPassword = ""    # 加密后的密码
randomStr = ""  # 登录随机字符串
# 登录参数
loginData = {"grant_type": "password", "isSerialize": "true", "username": username, "password": desPassword}

@pytest.fixture(scope='session')
def get_token():
    print('会话级别的 fixture get token')
    return get_login_token()


def get_login_token():
    # 获取登录随机字符串
    url = baseUrl + "/secret/" + username
    res = requests.get(url=url)
    global randomStr
    randomStr = res.json()['data']
    # 加密
    Des_Key = randomStr  # Key
    Des_IV = {1, 2, 3, 4, 5, 6, 7, 8}  # 自定IV向量
    k = des(Des_Key, CBC, Des_IV, pad=None, padmode=PAD_PKCS5)
    EncryptStr = k.encrypt(password)
    global desPassword
    desPassword = base64.b64encode(EncryptStr).decode('ascii')
    loginData['password'] = desPassword
    # 登录
    url = baseUrl + "/login"
    res = requests.post(url=url, data=loginData)
    token = res.json()['data']['accessToken']
    print(token)
    conf.update_value("user.conf", "headers", "token", token)
    return token

if __name__ == "__main__":
    get_login_token()