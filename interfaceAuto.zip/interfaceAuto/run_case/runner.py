#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/6/3 下午4:33
# @Author  : yuan.li
import os
import sys
base_dir = str(os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir)))
sys.path.append(base_dir)
import pytest
from common.config import Config
from common.shellUtil import Shell

print("当前的工作目录：",os.getcwd())

if __name__ == "__main__":
    config = Config()
    shell = Shell()

    test_case_path = config.test_case_path
    xml_report_path = config.xml_report_path
    html_report_path = config.html_report_path
    log_path = config.log_path

    # 删除当前 logFile 下的内容
    logFile = os.listdir(log_path)
    for i in logFile:
        file = os.path.join(log_path, i)
        os.remove(file)

    #删除当前xml下面内容
    ls = os.listdir(xml_report_path)
    for i in ls:
        file = os.path.join(xml_report_path,i)
        os.remove(file)

    # args = ["-m", "othercases", "--alluredir", xml_report_path]
    args = [test_case_path, "--alluredir", xml_report_path]
    pytest.main(args)

    cmd = "allure generate "+xml_report_path+" -o "+html_report_path+" --clean"
    print(cmd)

    try:
        shell.invoke(cmd)
    except:
        print("运行失败")

