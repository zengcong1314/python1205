#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/5/23 10:56 下午
# @Author  : yuan.li
# 请求封装
from common.excelReader import ExcelReader
from common.logger import Logger
import requests
import json
logger = Logger().getlog()
from common.config import Config

conf = Config()
env = conf.get_value("run.conf", "execution", "env")
host = conf.get_value("host.conf", env, "host")
data_path = conf.data_path

def get_headers():
    token = conf.get_value("user.conf", "headers", "token")
    print(f"conf 文件中读取出来的 token: {token}")
    headers = {"authorization": "bearer " + token}
    print(f"get_header 函数返回的 header: {headers}")
    return headers


class SendRequest():
    @staticmethod
    def request_api(method='', url='', headers='', data=''):
        resUrl = host + url
        if not resUrl.startswith("http"):
            resUrl = "http://" + resUrl
        logger.info("init url for the test %s" % resUrl)

        if headers == "" and headers is not None:
            headers = get_headers()

        try:
            if method == "GET":
                if headers is None:
                    if data is None or data == "":
                        res = requests.get(url=resUrl)
                    else:
                        res = requests.get(url=resUrl, params=data)
                else:
                    if data is None or data == "":
                        res = requests.get(url=resUrl, headers=headers)
                    else:
                        res = requests.get(url=resUrl, headers=headers, params=data)
                print(f"request headers: {headers}")
                print(f"request url: {res.url}")
                print(f"request params: {data}")
                print(f"status code: {res.status_code}")
                print(res.json())
                return res

            if method == "POST":
                if headers is None:
                    if data is None or data == "":
                        res = requests.post(url=resUrl)
                    else:
                        if "application/x-www-form-urlencoded" in headers:
                            res = requests.post(url=resUrl, data=data)
                        else:
                            res = requests.post(url=resUrl, json=data)
                else:
                    if data is None or data == "":
                        res = requests.post(url=resUrl, headers = headers)
                    else:
                        if "application/x-www-form-urlencoded" in headers:
                            res = requests.post(url=resUrl, headers=headers, data=data)
                        else:
                            res = requests.post(url=resUrl, headers=headers, json=data)
                print(f"request url: {res.url}")
                print(f"request json: {data}")
                print(f"status code: {res.status_code}")
                print(res.json())
                return res

            if method == "PUT":
                if headers is None:
                    if data is None or data == "":
                        res = requests.put(url=resUrl)
                    else:
                        if "application/x-www-form-urlencoded" in headers:
                            res = requests.put(url=resUrl, data=data)
                        else:
                            res = requests.put(url=resUrl, json=data)
                else:
                    if data is None or data == "":
                        res = requests.put(url=resUrl, headers = headers)
                    else:
                        if "application/x-www-form-urlencoded" in headers:
                            res = requests.put(url=resUrl, headers=headers, data=data)
                        else:
                            res = requests.put(url=resUrl, headers=headers, json=data)
                print(f"request url: {res.url}")
                print(f"request json: {data}")
                print(f"status code: {res.status_code}")
                print(res.json())
                return res

            if method == "DELETE":
                if headers is None:
                    if data is None or data == "":
                        res = requests.delete(url=resUrl)
                    else:
                        res = requests.delete(url=resUrl, data=data)
                else:
                    if data is None or data == "":
                        res = requests.delete(url=resUrl, headers=headers)
                    else:
                        res = requests.delete(url=resUrl, headers=headers, data=data)
                print(f"request url: {res.url}")
                print(f"status code: {res.status_code}")
                print(res.json())
                return res

            if method == "UPLOAD":
                if headers is None:
                    res = requests.post(url=resUrl, files=data)
                else:
                    res = requests.post(url=resUrl, headers=headers, files=data)
                print(f"request url: {res.url}")
                print(f"request json: {data}")
                print(f"status code: {res.status_code}")
                print(res.json())
                return res

            if method == "DOWNLOAD":
                if headers is None:
                    if data is None or data == "":
                        res = requests.get(url=url)
                    else:
                        res = requests.get(url=url, params=data)
                else:
                    if data is None or data == "":
                        res = requests.get(url=url, headers=headers)
                    else:
                        res = requests.get(url=url, headers=headers, params=data)
                print(f"request url: {res.url}")
                print(f"request json: {data}")
                print(f"status code: {res.status_code}")
                print(res.content)
                return res

        except:
            print("服务器访问失败")


if __name__ == "__main__":
    filezpath = "testdata.xlsx"
    at = ExcelReader(filezpath)
    op = at.get_excel_value()
    send = SendRequest()
    for l in op:
        print(send.request_api(l["method"],l["url"],l["headers"],l["data"]).text)
