#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/5/23 10:57 下午
# @Author  : yuan.li
from common.config import Config
from common.excelReader import ExcelReader
import allure
import pytest
from common.sendRequest import SendRequest

#调试用
# filezpath = "testdata.xlsx"
# at = CreateExcel(filezpath)
# op = at.datacel()
# host = "192.168.0.118:8080"
#读取配置文件
conf = Config()
env = conf.get_value("run.conf", "execution", "env")
date_file = conf.get_value("run.conf", "execution", "data")
host = conf.get_value("host.conf", env, "host")
#构造测试数据
excel = ExcelReader(date_file,0)
op = excel.get_excel_value()

excel = ExcelReader(date_file,1)
op1 = excel.get_excel_value()


data = []
for l in op:
    data.append(pytest.param(host,l["url"],l["method"],l["headers"],
                             l["data"],str(int(l["code"])),l["expect"],id=l["name"]))

data1 = []
for l in op1:
    data1.append(pytest.param(host,l["url"],l["method"],l["headers"],
                             l["data"],str(int(l["code"])),l["expect"],id=l["name"]))

@allure.story()
@pytest.mark.parametrize("host,url,method,headers,data,code,expect", data)
@pytest.mark.maincases
def testapis(host, url, method, headers, data, code, expect):
    # 初始化接口测试方法
    send = SendRequest()
    result = send.request_api(method, host, url, headers, data)
    assert str(result.status_code) == code
    assert expect in result.text


@allure.story()
@pytest.mark.parametrize("host,url,method,headers,data,code,expect", data1)
@pytest.mark.othercases
def testapi01(host, url, method, headers, data, code, expect):
    # 初始化接口测试方法
    send = SendRequest()
    result = send.request_api(method, host, url, headers, data)
    assert str(result.status_code) == code
    assert expect in result.text

