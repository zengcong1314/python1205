#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/5/23 10:57 下午
# @Author  : yuan.li
import subprocess


class Shell:
    @staticmethod
    def invoke(cmd):
        output, errors = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE,stderr=subprocess.PIPE).communicate()
        o = output.decode("unicode_escape")
        return o