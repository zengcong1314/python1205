#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/5/23 1:31 下午
# @Author  : LiYuan
# 封装公共类